/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventana;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.MouseInfo;
import java.awt.Point;
import javax.swing.JPanel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Toolkit;


/**
 *
 * @author Ricardo
 */
public class inicio extends javax.swing.JFrame {
int x,y;

 
config c1; 
 GridBagLayout layout = new GridBagLayout();
    consola p1;
    config p2;
    info p3;
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().
                getImage(ClassLoader.getSystemResource("resources/icono.png"));


        return retValue;
    }
    public inicio() {
        this.c1 = new config();
        initComponents();
        p1 = new consola();
        p2 = new config();
        p3 = new info();
        DynamicPanel.setLayout(layout);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        DynamicPanel.add(p1,c);
        DynamicPanel.add(p2,c);
        DynamicPanel.add(p3,c);
        p1.setVisible(true);
        p2.setVisible(false);
        p3.setVisible(false);
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondo = new javax.swing.JPanel();
        PanelLateral = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        botoninfo = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        botonconfig = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        botonC = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();
        cerrar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        DynamicPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        setLocationByPlatform(true);
        setUndecorated(true);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
        });
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                formKeyReleased(evt);
            }
        });

        fondo.setBackground(new java.awt.Color(255, 255, 255));
        fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelLateral.setBackground(new java.awt.Color(128, 0, 64));
        PanelLateral.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        PanelLateral.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 230, 10));

        botoninfo.setBackground(new java.awt.Color(128, 0, 64));
        botoninfo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botoninfo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                botoninfoMousePressed(evt);
            }
        });
        botoninfo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_Ask_Question_48px.png"))); // NOI18N
        botoninfo.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 60, 50));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 204, 204));
        jLabel6.setText("Información");
        botoninfo.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 190, 20));

        PanelLateral.add(botoninfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, -1, 60));

        botonconfig.setBackground(new java.awt.Color(128, 0, 64));
        botonconfig.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonconfig.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                botonconfigMousePressed(evt);
            }
        });
        botonconfig.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_Settings_48px.png"))); // NOI18N
        botonconfig.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 50, 40));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("Configuración");
        botonconfig.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 190, 20));

        PanelLateral.add(botonconfig, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, -1, 60));

        botonC.setBackground(new java.awt.Color(164, 0, 60));
        botonC.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                botonCMousePressed(evt);
            }
        });
        botonC.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_CNC_Machine_48px_1.png"))); // NOI18N
        botonC.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 60, 50));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 204, 204));
        jLabel7.setText("Consola de comandos");
        botonC.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 190, 20));

        PanelLateral.add(botonC, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 260, 60));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 204, 204));
        jLabel1.setText("Transmisión de código G");
        PanelLateral.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, 210, 30));

        fondo.add(PanelLateral, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 640));

        jPanel1.setBackground(new java.awt.Color(168, 0, 80));

        titulo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(227, 227, 228));
        titulo.setText("¿Qué quieres dibujar hoy?");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 421, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(257, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(titulo)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        fondo.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 720, -1));

        cerrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_Close_Window_48px.png"))); // NOI18N
        cerrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cerrarActionPerformed(evt);
            }
        });
        fondo.add(cerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 0, 33, 30));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ITD.png"))); // NOI18N
        fondo.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 0, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("Instituto Tecnológico de Durango");
        fondo.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 30, -1, -1));

        DynamicPanel.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout DynamicPanelLayout = new javax.swing.GroupLayout(DynamicPanel);
        DynamicPanel.setLayout(DynamicPanelLayout);
        DynamicPanelLayout.setHorizontalGroup(
            DynamicPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 720, Short.MAX_VALUE)
        );
        DynamicPanelLayout.setVerticalGroup(
            DynamicPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 470, Short.MAX_VALUE)
        );

        fondo.add(DynamicPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 160, 720, 470));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(fondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cerrarActionPerformed
       System.exit(0);
    }//GEN-LAST:event_cerrarActionPerformed

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
        
        x=evt.getX();
        y=evt.getY();
    }//GEN-LAST:event_formMousePressed

    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
       Point point = MouseInfo.getPointerInfo().getLocation();
       setLocation(point.x - x,point.y - y);
       
    }//GEN-LAST:event_formMouseDragged

    private void botonCMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCMousePressed
        setColor(botonC);
        resetColor(botonconfig);
        resetColor(botoninfo);
     p1.setVisible(true);
        p2.setVisible(false);
        p3.setVisible(false);
        titulo.setText("¿Qué quieres dibujar hoy?");
    
       
        
    }//GEN-LAST:event_botonCMousePressed

    private void botonconfigMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonconfigMousePressed
        
        setColor(botonconfig);
        resetColor(botonC);
        resetColor(botoninfo);
      p1.setVisible(false);
        p2.setVisible(true);
        p3.setVisible(false);
        titulo.setText("Configura tu puerto");
    }//GEN-LAST:event_botonconfigMousePressed

    private void botoninfoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botoninfoMousePressed
        setColor(botoninfo);
        resetColor(botonconfig);
        resetColor(botonC);
        p1.setVisible(false);
        p2.setVisible(false);
        p3.setVisible(true);
        titulo.setText("Algo de información útil...");
    }//GEN-LAST:event_botoninfoMousePressed

    private void formKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyReleased
       // TODO add your handling code here:
    }//GEN-LAST:event_formKeyReleased

    void setColor(JPanel panel){
        panel.setBackground(new Color(164,0,60));
    }
    void resetColor(JPanel panel){
        panel.setBackground(new Color(128,0,64));
    }
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel DynamicPanel;
    private javax.swing.JPanel PanelLateral;
    private javax.swing.JPanel botonC;
    private javax.swing.JPanel botonconfig;
    private javax.swing.JPanel botoninfo;
    private javax.swing.JButton cerrar;
    private javax.swing.JPanel fondo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
