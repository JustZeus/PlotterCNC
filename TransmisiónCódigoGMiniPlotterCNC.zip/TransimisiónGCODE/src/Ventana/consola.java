/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventana;

import com.panamahitek.PanamaHitek_Arduino;
import java.awt.event.KeyEvent;
import jssc.SerialPortEventListener;
import com.panamahitek.ArduinoException;
import com.panamahitek.PanamaHitek_Arduino;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;



/**
 *
 * @author Ricardo
 */


public class consola extends javax.swing.JPanel {
 String texto ="";
 int cuenta;
 int baud;
 int x =0, y=0;
 int i;
 String [] gcode;
   String puerto;
   String baudios; 
   String mensaje; 
   String GX;
   boolean msj =true;
   boolean cnx =true;
   boolean clk =true;
   boolean z=true;
   boolean stream=false;
  
  
     PanamaHitek_Arduino Arduino=new PanamaHitek_Arduino();
    SerialPortEventListener Objeto=new SerialPortEventListener() 
    {
        @Override
        public void serialEvent(SerialPortEvent spe) 
        {
        }
    };
    
    public consola() {
        initComponents();
        pantalla.setEditable(false);
   
   config co = new config();
   puerto= co.npuerto.getText();
   baudios= co.tbaudios.getText();
  
   baud = Integer.parseInt(baudios);
   KeyListener teclado = new KeyListener() {
         @Override
         public void keyTyped(KeyEvent ke) {
             
         }
         
         @Override
         public void keyPressed(KeyEvent ke) {
            
         }
         
         @Override
         public void keyReleased(KeyEvent ke) {
      int tecla=ke.getKeyCode();
      if (tecla==KeyEvent.VK_RIGHT){
          x--;
          if(x<0)x=0; 
          
          arduino();
          
          textopantalla();
      } 
      
      
       if (tecla==KeyEvent.VK_LEFT){
          x++;
          if(x>39)x=39; 
          
          arduino();
          
          textopantalla();
      } 
       
       
        if (tecla==KeyEvent.VK_UP){
          y++;
          if(y>39)y=39; 
          
          arduino();
          
          textopantalla();
          
      } 
        
         if (tecla==KeyEvent.VK_DOWN){
          y--;
          if(y<0)y=0; 
          
          arduino();
          
          textopantalla();
      } 
        
         if (tecla==KeyEvent.VK_Z){
          y--;x++;
          if(y<0)y=0;
          if(x>39)x=39;
          
          arduino();
          
          textopantalla();
      } 

           if (tecla==KeyEvent.VK_E){
          y++;x--;
          if(y>39)y=39;
          if(x<0)x=0;
          
          arduino();
          
          textopantalla();
      } 

      
           if (tecla==KeyEvent.VK_Q){
          y++;x++;
          if(y>39)y=39;
          if(x>39)x=39;
          
          arduino();
          
          textopantalla();
      } 

      
         
         
         
           if (tecla==KeyEvent.VK_C){
          y--;x--;
          if(y<0)y=0;
          if(x<0)x=0;
          
          arduino();
          
          textopantalla();
      } 
           
           
                if (tecla==KeyEvent.VK_SPACE){
          
                    
                      if(z)
                      {
                      try {
         Arduino.sendByte(68);
     } catch (            ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
     
     
      try {
         Arduino.sendByte(10);
     } catch (            ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
                      
                      z=false;
                          
                      }
         else
           {
           
               
         try {
         Arduino.sendByte(85);
     } catch (ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
     
         
         
       
      try {
         Arduino.sendByte(10);
     } catch (            ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
               
               
              z=true; 
           }                 
                    
                    
                    
                    
                    
                    
                    
                    
          
      } 


      
         }
      
         
         
     };
    pantalla.addKeyListener(teclado);
   
   
   
  
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFileChooser1 = new javax.swing.JFileChooser();
        Zmas = new javax.swing.JButton();
        xmas = new javax.swing.JButton();
        ymenos = new javax.swing.JButton();
        Etexto = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        ymas = new javax.swing.JButton();
        Zmenos = new javax.swing.JButton();
        conectar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        enviar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        pantalla = new javax.swing.JTextPane();
        home = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        xmenos = new javax.swing.JButton();
        Archivo = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                formKeyReleased(evt);
            }
        });

        Zmas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Zmas.setText("+Z");
        Zmas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZmasActionPerformed(evt);
            }
        });

        xmas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        xmas.setText("+x");
        xmas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                xmasActionPerformed(evt);
            }
        });

        ymenos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ymenos.setText("-y");
        ymenos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ymenosActionPerformed(evt);
            }
        });

        Etexto.setText("Ingrese codigo G");
        Etexto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EtextoMouseClicked(evt);
            }
        });
        Etexto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EtextoActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jLabel2.setText("Controles del CNC");

        ymas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ymas.setText("+y");
        ymas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ymasActionPerformed(evt);
            }
        });

        Zmenos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Zmenos.setText("-Z");
        Zmenos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZmenosActionPerformed(evt);
            }
        });

        conectar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        conectar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_Ok_48px.png"))); // NOI18N
        conectar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        conectar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                conectarActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jLabel3.setText("Conectar");

        enviar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_Enter_Key_48px.png"))); // NOI18N
        enviar.setBorder(null);
        enviar.setBorderPainted(false);
        enviar.setContentAreaFilled(false);
        enviar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        enviar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_Enter_Key_30px_1.png"))); // NOI18N
        enviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enviarActionPerformed(evt);
            }
        });
        enviar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                enviarKeyPressed(evt);
            }
        });

        jScrollPane1.setViewportView(pantalla);

        home.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_Home_48px.png"))); // NOI18N
        home.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jLabel4.setText("0 Máquina");

        xmenos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        xmenos.setText("-x");
        xmenos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                xmenosActionPerformed(evt);
            }
        });

        Archivo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_Opened_Folder_34px.png"))); // NOI18N
        Archivo.setBorder(null);
        Archivo.setBorderPainted(false);
        Archivo.setContentAreaFilled(false);
        Archivo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Archivo.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_Opened_Folder_29px.png"))); // NOI18N
        Archivo.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/icons8_Opened_Folder_40px.png"))); // NOI18N
        Archivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ArchivoActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jLabel1.setText("Importar");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 194, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1)
                            .addComponent(Etexto, javax.swing.GroupLayout.DEFAULT_SIZE, 271, Short.MAX_VALUE))
                        .addGap(67, 67, 67))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(xmenos, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(ymenos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Zmas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(ymas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Zmenos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(xmas, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(33, 33, 33)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel4))
                                        .addGap(401, 401, 401)
                                        .addComponent(enviar))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(conectar, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(20, 20, 20)
                                        .addComponent(jLabel3)))
                                .addGap(14, 14, 14)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Archivo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(conectar, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(29, 29, 29)
                                        .addComponent(xmas)
                                        .addGap(59, 59, 59)
                                        .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(ymas)
                                        .addGap(18, 18, 18)
                                        .addComponent(ymenos)
                                        .addGap(41, 41, 41)
                                        .addComponent(Zmas)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(Zmenos))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addComponent(xmenos))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Archivo, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(192, 192, 192)))
                        .addGap(34, 34, 34)
                        .addComponent(Etexto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(enviar, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap(36, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    
    public void arduino() {
       
        String GY="G90\nG20\nG00";
        
        GX ="X "+x+".000 Y"+y+".000 Z00.000\n";
        String envio= GY+GX;
        try {
         Arduino.sendData(envio);
     } catch (ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
        
    }
    public void textopantalla(){
    texto=texto +cuenta++ +": G00"+GX+"\n";
        pantalla.setText(texto);
    
    }

    public void archivo() throws FileNotFoundException, IOException, ArduinoException, SerialPortException
    {
        gcode = null; i = 0;
     
    int returnVal = jFileChooser1.showOpenDialog(this);
    if (returnVal == JFileChooser.APPROVE_OPTION) {
        
         
        
        
        
        
        
       BufferedReader reader = new BufferedReader(new FileReader(jFileChooser1.getSelectedFile().getPath())); // What to do with the file, e.g. display it in a TextArea
       String text="";
       String line= reader.readLine();
      while(line!=null)
      {
      text+= line+"\n";
      line= reader.readLine();
      
      }
      
       gcode = text.split("\n");
      
      for(int i =0; i<gcode.length; i++){
       System.out.println(gcode[i]);
      }
    } else {
        System.out.println("El usuario cancelo la selección de archivo");
    }
   stream=true;
  
   streaming();
    
    
    
    }
    
    public void display()
    {
    
        pantalla.setText(gcode[i] + '\n');
return;        
    }
    
    public void  streaming() throws ArduinoException, SerialPortException
    {
    
      if (!stream) return;
  
  while (true) {
    if (i == gcode.length) {
      stream = false;
      return;
    }
    
    if (gcode[i].trim().length() == 0) i++;
    else break;
  }
  
  
  Arduino.sendData(gcode[i] + '\n');
 display();
  i++;
recepcion();
    }
    
public void recepcion () throws SerialPortException, ArduinoException
    {
       while(true)
       {
    if(Arduino.isMessageAvailable())
    {
        if (i == gcode.length) break;
      
        String respuesta =Arduino.printMessage();
         streaming();
        
    }
        
    
    
        } 
        
        
    
    
    
    }
    
    
    
    private void EtextoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EtextoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EtextoActionPerformed

    private void ZmasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZmasActionPerformed
       
        
        
         try {
         Arduino.sendByte(85);
     } catch (ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
     
         
         
       
      try {
         Arduino.sendByte(10);
     } catch (ArduinoException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     } catch (SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
    }//GEN-LAST:event_ZmasActionPerformed

    private void ymenosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ymenosActionPerformed
        y--;
        arduino();
     
        
        textopantalla();
    }//GEN-LAST:event_ymenosActionPerformed

    private void ymasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ymasActionPerformed
         y++;
        arduino();
        
        textopantalla();
    }//GEN-LAST:event_ymasActionPerformed

    private void ZmenosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZmenosActionPerformed
     
     try {
         Arduino.sendByte(68);
     } catch (ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
     
     
      try {
         Arduino.sendByte(10);
     } catch (ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
     
      
     
     
    }//GEN-LAST:event_ZmenosActionPerformed

    private void conectarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_conectarActionPerformed
       
        
       if(cnx){
         try 
        {
            Arduino.arduinoRXTX(puerto,baud, Objeto);
        } 
        catch (ArduinoException ex) 
        {
            Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
        }
  
       
         
         
        
         pantalla.setText("CNC viva y lista para echarle watts\nConexión completa");
         System.out.print(mensaje);
         cnx=false;
        
       }
        
     
       
    }//GEN-LAST:event_conectarActionPerformed

    private void EtextoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EtextoMouseClicked
       
        if(clk){
        Etexto.setText("G00 X00.000 Y00.000 Z00.000");
        clk=false;
        
        }
    }//GEN-LAST:event_EtextoMouseClicked

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed
x=0;
y=0;
        try {
         Arduino.sendData("G90\nG20\nG00 X00.000 Y00.000 Z00.000\n");
     } catch (ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
    }//GEN-LAST:event_homeActionPerformed

    private void xmenosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_xmenosActionPerformed
 if(x<0)x=0;    
        x--;
        arduino();
        
       textopantalla();
    }//GEN-LAST:event_xmenosActionPerformed

    private void enviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enviarActionPerformed
        
        texto=texto +cuenta++ +": "+ Etexto.getText()+"\n";
        pantalla.setText(texto);
        try {
         Arduino.sendData("G90\nG20\n"+Etexto.getText()+"\n");
     } catch (ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
        
        
        
        
    }//GEN-LAST:event_enviarActionPerformed

    private void enviarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_enviarKeyPressed
      
    }//GEN-LAST:event_enviarKeyPressed

    private void xmasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_xmasActionPerformed
     x++;
        arduino();
      
        
        textopantalla();
    }//GEN-LAST:event_xmasActionPerformed

    private void formKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyReleased
       
    }//GEN-LAST:event_formKeyReleased

    private void ArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ArchivoActionPerformed
     try {
          pantalla.setText("Dibujo en proceso\n espere por favor");
         archivo();
     } catch (IOException | ArduinoException | SerialPortException ex) {
         Logger.getLogger(consola.class.getName()).log(Level.SEVERE, null, ex);
     }
    }//GEN-LAST:event_ArchivoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Archivo;
    private javax.swing.JTextField Etexto;
    private javax.swing.JButton Zmas;
    private javax.swing.JButton Zmenos;
    private javax.swing.JButton conectar;
    private javax.swing.JButton enviar;
    private javax.swing.JButton home;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTextPane pantalla;
    private javax.swing.JButton xmas;
    private javax.swing.JButton xmenos;
    private javax.swing.JButton ymas;
    private javax.swing.JButton ymenos;
    // End of variables declaration//GEN-END:variables
}
